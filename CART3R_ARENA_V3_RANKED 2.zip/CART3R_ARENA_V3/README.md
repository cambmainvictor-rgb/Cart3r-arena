# CART3R ARENA V3 — Ranked

## Installation
```bash
python -m pip install pygame
```

## Lancement
```bash
python main.py
```

## Commandes
- ZQSD, WASD ou flèches : déplacement
- Clic gauche : tirer
- Entrée ou clic : lancer une partie / revenir au menu
- Échap : quitter ou revenir au menu

## Progression
Le mode classé se débloque à **5 000 trophées**.
Les trophées et l'ELO sont deux compteurs indépendants.

### Rangs Elo
- Bronze : 500
- Argent : 1 000
- Or : 1 500
- Diamant : 5 000
- Mythique : 6 500
- Légendaire : 7 850
- Master : 9 000

### Gains en victoire
- Bronze : +180 Elo
- Argent : +150 Elo
- Or : +120 Elo
- Diamant : +90 Elo
- Mythique : +70 Elo
- Légendaire : +70 Elo
- Master : +70 Elo

Défaite : **-110 Elo** (ELO minimum : 0).
Victoire : **+225 trophées**.
Défaite : **-2 trophées**.

Les données sont enregistrées dans `player_data.json`.
