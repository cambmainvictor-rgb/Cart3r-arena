import pygame
import random
import math
import json
import os

# CART3R.JAILBREAK — ARENA BRAWL
# Install: pip install pygame
# Run: python main.py

pygame.init()
WIDTH, HEIGHT = 1000, 650
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("CART3R ARENA")
clock = pygame.time.Clock()

WHITE = (245, 245, 245)
BLACK = (15, 17, 22)
RED = (235, 65, 75)
BLUE = (65, 155, 245)
GREEN = (70, 210, 125)
YELLOW = (250, 210, 75)
GRAY = (80, 88, 100)
DARK = (28, 33, 42)

FONT = pygame.font.SysFont("arial", 24, bold=True)
SMALL = pygame.font.SysFont("arial", 17)
BIG = pygame.font.SysFont("arial", 52, bold=True)

SAVE_FILE = "player_data.json"

def load_trophies():
    try:
        with open(SAVE_FILE, "r", encoding="utf-8") as f:
            return max(0, int(json.load(f).get("trophies", 0)))
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return 0

def save_trophies(value):
    with open(SAVE_FILE, "w", encoding="utf-8") as f:
        json.dump({"trophies": value}, f)

class Fighter:
    def __init__(self, x, y, color, is_player=False):
        self.x, self.y = float(x), float(y)
        self.color = color
        self.is_player = is_player
        self.radius = 19
        self.hp = 100
        self.max_hp = 100
        self.speed = 3.5 if is_player else random.uniform(1.5, 2.0)
        self.cooldown = 0
        self.alive = True
        self.ai_timer = 0
        self.wander_angle = random.random() * math.tau

    def move(self, dx, dy, obstacles):
        length = math.hypot(dx, dy)
        if length:
            dx, dy = dx / length, dy / length
        nx = max(self.radius, min(WIDTH - self.radius, self.x + dx * self.speed))
        ny = max(90 + self.radius, min(HEIGHT - self.radius, self.y + dy * self.speed))
        candidate = pygame.Rect(nx-self.radius, ny-self.radius,
                                self.radius*2, self.radius*2)
        if not any(candidate.colliderect(o) for o in obstacles):
            self.x, self.y = nx, ny

    def draw(self, surface):
        pygame.draw.circle(surface, self.color, (int(self.x), int(self.y)), self.radius)
        pygame.draw.circle(surface, WHITE, (int(self.x), int(self.y)), self.radius, 2)
        bar_w = 46
        pygame.draw.rect(surface, (65, 30, 35),
                         (self.x-bar_w/2, self.y-32, bar_w, 6), border_radius=3)
        pygame.draw.rect(surface, GREEN if self.hp > 35 else RED,
                         (self.x-bar_w/2, self.y-32, bar_w*self.hp/self.max_hp, 6),
                         border_radius=3)

class Projectile:
    def __init__(self, x, y, dx, dy, owner):
        length = max(1, math.hypot(dx, dy))
        self.x, self.y = x, y
        self.dx, self.dy = dx/length*8, dy/length*8
        self.owner = owner
        self.radius = 6
        self.damage = 25

    def update(self):
        self.x += self.dx
        self.y += self.dy
        return (0 <= self.x <= WIDTH and 85 <= self.y <= HEIGHT)

    def draw(self, surface):
        pygame.draw.circle(surface, YELLOW, (int(self.x), int(self.y)), self.radius)

def make_obstacles():
    return [
        pygame.Rect(260, 180, 120, 45),
        pygame.Rect(620, 180, 120, 45),
        pygame.Rect(430, 310, 140, 55),
        pygame.Rect(250, 455, 110, 45),
        pygame.Rect(640, 455, 110, 45),
    ]

def draw_arena(surface, obstacles):
    surface.fill((38, 92, 73))
    # Subtle arena grid
    for x in range(0, WIDTH, 50):
        pygame.draw.line(surface, (43, 99, 79), (x, 90), (x, HEIGHT), 1)
    for y in range(90, HEIGHT, 50):
        pygame.draw.line(surface, (43, 99, 79), (0, y), (WIDTH, y), 1)
    for rect in obstacles:
        pygame.draw.rect(surface, (115, 119, 105), rect, border_radius=8)
        pygame.draw.rect(surface, (75, 80, 75), rect, 3, border_radius=8)

def draw_text(surface, text, font, color, x, y, center=False):
    image = font.render(text, True, color)
    rect = image.get_rect()
    if center:
        rect.center = (x, y)
    else:
        rect.topleft = (x, y)
    surface.blit(image, rect)

def main():
    trophies = load_trophies()
    state = "menu"
    result_message = ""
    reward = 0
    player = None
    enemies = []
    bullets = []
    obstacles = make_obstacles()
    match_start = 0
    MATCH_SECONDS = 100

    running = True
    while running:
        dt = clock.tick(60) / 1000
        now = pygame.time.get_ticks()
        mouse = pygame.mouse.get_pos()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    if state == "playing":
                        state = "menu"
                    else:
                        running = False
                if state == "menu" and event.key in (pygame.K_RETURN, pygame.K_SPACE):
                    state = "playing"
                elif state in ("win", "lose") and event.key in (pygame.K_RETURN, pygame.K_SPACE):
                    state = "menu"
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if state == "menu":
                    state = "playing"
                elif state in ("win", "lose"):
                    state = "menu"
                elif state == "playing" and player and player.alive:
                    dx, dy = mouse[0] - player.x, mouse[1] - player.y
                    if player.cooldown <= 0:
                        bullets.append(Projectile(player.x, player.y, dx, dy, player))
                        player.cooldown = 0.32

        if state == "menu":
            screen.fill(BLACK)
            draw_text(screen, "CART3R ARENA", BIG, RED, WIDTH//2, 170, True)
            draw_text(screen, "Mini jeu d'arene en Python / Pygame", FONT, WHITE, WIDTH//2, 230, True)
            draw_text(screen, f"Trophees : {trophies}", FONT, YELLOW, WIDTH//2, 300, True)
            draw_text(screen, "ZQSD / WASD ou fleches : bouger", SMALL, WHITE, WIDTH//2, 385, True)
            draw_text(screen, "Clic gauche : tirer | Entree ou clic : jouer", SMALL, WHITE, WIDTH//2, 415, True)
            draw_text(screen, "Echap : quitter", SMALL, GRAY, WIDTH//2, 455, True)
            pygame.display.flip()
            continue

        if state == "playing":
            keys = pygame.key.get_pressed()
            if player is None:
                player = Fighter(WIDTH/2, HEIGHT-100, BLUE, True)
                enemies = [
                    Fighter(150, 150, RED),
                    Fighter(850, 150, RED),
                    Fighter(500, 150, RED),
                ]
                bullets = []
                match_start = now

            dx = (keys[pygame.K_d] or keys[pygame.K_RIGHT]) - (keys[pygame.K_a] or keys[pygame.K_LEFT])
            dy = (keys[pygame.K_s] or keys[pygame.K_DOWN]) - (keys[pygame.K_w] or keys[pygame.K_UP])
            player.move(dx, dy, obstacles)
            player.cooldown = max(0, player.cooldown - dt)

            living_enemies = [e for e in enemies if e.alive]
            for enemy in living_enemies:
                enemy.cooldown = max(0, enemy.cooldown - dt)
                vx, vy = player.x-enemy.x, player.y-enemy.y
                distance = max(1, math.hypot(vx, vy))
                if distance > 220:
                    enemy.move(vx, vy, obstacles)
                elif distance < 145:
                    enemy.move(-vx, -vy, obstacles)
                else:
                    enemy.ai_timer -= dt
                    if enemy.ai_timer <= 0:
                        enemy.wander_angle = random.random()*math.tau
                        enemy.ai_timer = random.uniform(0.5, 1.2)
                    enemy.move(math.cos(enemy.wander_angle), math.sin(enemy.wander_angle), obstacles)
                if distance < 430 and enemy.cooldown <= 0:
                    bullets.append(Projectile(enemy.x, enemy.y, vx, vy, enemy))
                    enemy.cooldown = random.uniform(0.8, 1.25)

            for bullet in bullets[:]:
                if not bullet.update():
                    bullets.remove(bullet)
                    continue
                targets = [e for e in enemies if e.alive] if bullet.owner is player else ([player] if player.alive else [])
                hit = False
                for target in targets:
                    if math.hypot(target.x-bullet.x, target.y-bullet.y) < target.radius+bullet.radius:
                        target.hp -= bullet.damage
                        if target.hp <= 0:
                            target.alive = False
                        hit = True
                        break
                if hit:
                    bullets.remove(bullet)

            if not player.alive:
                state = "lose"
                result_message = "DEFAITE"
                reward = -2
            elif not any(e.alive for e in enemies):
                state = "win"
                result_message = "VICTOIRE"
                reward = 225
            elif (now - match_start)/1000 >= MATCH_SECONDS:
                state = "lose"
                result_message = "TEMPS ECOULE"
                reward = -2

            if state in ("win", "lose"):
                trophies = max(0, trophies + reward)
                save_trophies(trophies)
                player = None

            draw_arena(screen, obstacles)
            pygame.draw.rect(screen, DARK, (0, 0, WIDTH, 82))
            draw_text(screen, f"TES TROPHEES : {trophies}", FONT, YELLOW, 20, 22)
            remaining = max(0, MATCH_SECONDS - int((now-match_start)/1000))
            draw_text(screen, f"TEMPS : {remaining}s", FONT, WHITE, WIDTH-170, 22)
            for enemy in enemies:
                if enemy.alive:
                    enemy.draw(screen)
            if player and player.alive:
                player.draw(screen)
            for bullet in bullets:
                bullet.draw(screen)
            draw_text(screen, "ZQSD / WASD / fleches : bouger  |  Clic gauche : tirer",
                      SMALL, WHITE, WIDTH//2, HEIGHT-25, True)

        elif state in ("win", "lose"):
            screen.fill(BLACK)
            color = GREEN if state == "win" else RED
            draw_text(screen, result_message, BIG, color, WIDTH//2, 205, True)
            draw_text(screen, f"{reward:+d} trophees", FONT, YELLOW, WIDTH//2, 285, True)
            draw_text(screen, f"Nouveau total : {trophies}", FONT, WHITE, WIDTH//2, 335, True)
            draw_text(screen, "Entree ou clic pour revenir au menu", SMALL, GRAY, WIDTH//2, 420, True)

        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()
