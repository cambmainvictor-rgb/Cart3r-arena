# CART3R ARENA

Mini-jeu d'arène 2D en Python avec Pygame.

## Installation
```bash
python -m pip install pygame
```

## Lancement
```bash
python main.py
```

## Commandes
- ZQSD, WASD ou flèches : déplacer le personnage
- Clic gauche : tirer
- Entrée ou clic : démarrer / revenir au menu
- Échap : quitter ou revenir au menu

## Trophées
- Victoire : +225
- Défaite ou temps écoulé : -2
- Le total est sauvegardé dans `player_data.json`.

Le jeu est un prototype original inspiré du genre arène, sans assets ni éléments propriétaires de Brawl Stars.
